
<div class="max-w-6xl mx-auto">
    <div class="bg-white shadow-sm rounded-lg p-6">
        <div class="flex items-start justify-between gap-4">
            <div>
                <h2 class="text-lg font-semibold">Gestione servizi</h2>
                <p class="text-sm text-gray-600 mt-1">
                    Configura i tuoi servizi: selezione, contenuti, slot e template settimanale.
                </p>
            </div>
        </div>

        
        <div class="mt-6 border-b">
            <nav class="-mb-px flex gap-6" aria-label="Tabs">

                <button type="button" wire:click="setTab('offerings')"
                    class="whitespace-nowrap py-3 px-1 border-b-2 text-sm font-medium
                        <?php echo e($activeTab === 'offerings' ? 'border-slate-600 text-slate-600' : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'); ?>">
                    Servizi
                </button>

                <button type="button" wire:click="setTab('content')"
                    class="whitespace-nowrap py-3 px-1 border-b-2 text-sm font-medium
                        <?php echo e($activeTab === 'content' ? 'border-slate-600 text-slate-600' : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'); ?>">
                    Contenuti
                </button>

                <button type="button" wire:click="setTab('slots')"
                    class="whitespace-nowrap py-3 px-1 border-b-2 text-sm font-medium
                        <?php echo e($activeTab === 'slots' ? 'border-slate-600 text-slate-600' : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'); ?>">
                    Slot
                </button>

                <button type="button" wire:click="setTab('weekly')"
                    class="whitespace-nowrap py-3 px-1 border-b-2 text-sm font-medium
                        <?php echo e($activeTab === 'weekly' ? 'border-slate-600 text-slate-600' : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'); ?>">
                    Template settimanale
                </button>

                <button type="button" wire:click="setTab('blackouts')"
                    class="whitespace-nowrap py-3 px-1 border-b-2 text-sm font-medium
                        <?php echo e($activeTab === 'blackouts' ? 'border-slate-600 text-slate-600' : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'); ?>">
                    Blackout
                </button>

                <button type="button" wire:click="setTab('leadtime')"
                    class="whitespace-nowrap py-3 px-1 border-b-2 text-sm font-medium
                        <?php echo e($activeTab === 'leadtime' ? 'border-slate-600 text-slate-600' : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'); ?>">
                    Lead time
                </button>

            </nav>
        </div>

        
        <div class="mt-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeTab === 'offerings'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.offerings.manage-offerings', []);

$key = 'tab-offerings';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-4212128870-0', 'tab-offerings');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php elseif($activeTab === 'content'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.offerings.manage-offering-contents', []);

$key = 'tab-content';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-4212128870-1', 'tab-content');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php elseif($activeTab === 'slots'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.offerings.manage-vendor-slots', []);

$key = 'tab-slots';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-4212128870-2', 'tab-slots');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php elseif($activeTab === 'weekly'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.offerings.manage-weekly-schedule', []);

$key = 'tab-weekly';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-4212128870-3', 'tab-weekly');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php elseif($activeTab === 'blackouts'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.offerings.manage-blackouts', []);

$key = 'tab-blackouts';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-4212128870-4', 'tab-blackouts');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php elseif($activeTab === 'leadtime'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.offerings.manage-lead-times', []);

$key = 'tab-leadtime';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-4212128870-5', 'tab-leadtime');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\b2b.partylegacy.it\resources\views/livewire/vendor/offerings/manage-offerings-tabs.blade.php ENDPATH**/ ?>