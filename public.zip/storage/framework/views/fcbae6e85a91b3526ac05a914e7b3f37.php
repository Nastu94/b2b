<div class="space-y-6">
    <div>
        <h2 class="text-lg font-semibold text-slate-900">Simulazione</h2>
        <p class="mt-1 text-sm text-slate-600">
            Inserisci un contesto di prova per verificare quali regole potrebbero entrare in gioco per questo listino.
        </p>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->pricing === null): ?>
        <div class="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            Prima di usare la simulazione devi creare il listino base del servizio.
        </div>
    <?php else: ?>
        <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <form wire:submit="simulate" class="space-y-6">
                <div class="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
                    <div>
                        <label for="simulation_event_date" class="mb-2 block text-sm font-medium text-slate-700">
                            Data evento
                        </label>

                        <input
                            id="simulation_event_date"
                            type="date"
                            wire:model.defer="simulation.event_date"
                            class="block w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-slate-400 focus:ring-slate-300"
                        >

                        <p class="mt-2 text-xs text-slate-500">
                            Serve per simulare eventuali regole con intervalli di date.
                        </p>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['simulation.event_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div>
                        <label for="simulation_weekday" class="mb-2 block text-sm font-medium text-slate-700">
                            Giorno della settimana
                        </label>

                        <select
                            id="simulation_weekday"
                            wire:model.defer="simulation.weekday"
                            class="block w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-slate-400 focus:ring-slate-300"
                        >
                            <option value="">-- Automatico / non specificato --</option>
                            <option value="1">Lunedì</option>
                            <option value="2">Martedì</option>
                            <option value="3">Mercoledì</option>
                            <option value="4">Giovedì</option>
                            <option value="5">Venerdì</option>
                            <option value="6">Sabato</option>
                            <option value="7">Domenica</option>
                        </select>

                        <p class="mt-2 text-xs text-slate-500">
                            Se lasci vuoto e imposti una data evento, il giorno verrà ricavato automaticamente.
                        </p>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['simulation.weekday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div>
                        <label for="simulation_distance_km" class="mb-2 block text-sm font-medium text-slate-700">
                            Distanza (km)
                        </label>

                        <input
                            id="simulation_distance_km"
                            type="number"
                            step="0.01"
                            min="0"
                            wire:model.defer="simulation.distance_km"
                            class="block w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-slate-400 focus:ring-slate-300"
                        >

                        <p class="mt-2 text-xs text-slate-500">
                            Utile per testare regole collegate al raggio o a fasce di distanza.
                        </p>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['simulation.distance_km'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div>
                        <label for="simulation_lead_days" class="mb-2 block text-sm font-medium text-slate-700">
                            Anticipo prenotazione (giorni)
                        </label>

                        <input
                            id="simulation_lead_days"
                            type="number"
                            min="0"
                            wire:model.defer="simulation.lead_days"
                            class="block w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-slate-400 focus:ring-slate-300"
                        >

                        <p class="mt-2 text-xs text-slate-500">
                            Indica quanti giorni prima dell'evento viene effettuata la prenotazione.
                        </p>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['simulation.lead_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div>
                        <label for="simulation_guests" class="mb-2 block text-sm font-medium text-slate-700">
                            Numero ospiti
                        </label>

                        <input
                            id="simulation_guests"
                            type="number"
                            min="1"
                            wire:model.defer="simulation.guests"
                            class="block w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-slate-400 focus:ring-slate-300"
                        >

                        <p class="mt-2 text-xs text-slate-500">
                            Serve per verificare eventuali regole che dipendono dalla capienza o dal numero di partecipanti.
                        </p>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['simulation.guests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <div class="flex items-center justify-end gap-3 border-t border-slate-200 pt-4">
                    <button
                        type="button"
                        wire:click="resetSimulation"
                        class="inline-flex items-center rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                    >
                        Reset
                    </button>

                    <button
                        type="submit"
                        class="inline-flex items-center rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
                    >
                        Simula
                    </button>
                </div>
            </form>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasSimulated): ?>
            <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">
                <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                    <h3 class="text-base font-semibold text-slate-900">Contesto simulato</h3>

                    <dl class="mt-4 space-y-4 text-sm">
                        <div class="flex items-start justify-between gap-4">
                            <dt class="text-slate-500">Data evento</dt>
                            <dd class="text-right font-medium text-slate-800">
                                <?php echo e(filled($simulation['event_date']) ? \Carbon\Carbon::parse($simulation['event_date'])->format('d/m/Y') : 'Non specificata'); ?>

                            </dd>
                        </div>

                        <div class="flex items-start justify-between gap-4">
                            <dt class="text-slate-500">Giorno</dt>
                            <dd class="text-right font-medium text-slate-800">
                                <?php echo e($this->weekdayLabel(filled($simulation['weekday']) ? (int) $simulation['weekday'] : null)); ?>

                            </dd>
                        </div>

                        <div class="flex items-start justify-between gap-4">
                            <dt class="text-slate-500">Distanza</dt>
                            <dd class="text-right font-medium text-slate-800">
                                <?php echo e(filled($simulation['distance_km']) ? number_format((float) $simulation['distance_km'], 2, ',', '.') . ' km' : 'Non specificata'); ?>

                            </dd>
                        </div>

                        <div class="flex items-start justify-between gap-4">
                            <dt class="text-slate-500">Anticipo</dt>
                            <dd class="text-right font-medium text-slate-800">
                                <?php echo e(filled($simulation['lead_days']) ? (int) $simulation['lead_days'] . ' giorni' : 'Non specificato'); ?>

                            </dd>
                        </div>

                        <div class="flex items-start justify-between gap-4">
                            <dt class="text-slate-500">Ospiti</dt>
                            <dd class="text-right font-medium text-slate-800">
                                <?php echo e(filled($simulation['guests']) ? (int) $simulation['guests'] : 'Non specificati'); ?>

                            </dd>
                        </div>
                    </dl>
                </div>

                <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                    <h3 class="text-base font-semibold text-slate-900">Esito simulazione</h3>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($simulationResult !== null): ?>
                        <div class="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                            <div class="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
                                <div class="text-xs font-medium uppercase tracking-wide text-slate-500">
                                    Prezzo base
                                </div>

                                <div class="mt-2 text-lg font-semibold text-slate-900">
                                    <?php echo e($this->formattedBasePrice()); ?>

                                </div>
                            </div>

                            <div class="rounded-lg border px-4 py-3 <?php echo e($this->hasResolvedPriceDifference() ? 'border-emerald-200 bg-emerald-50' : 'border-slate-200 bg-slate-50'); ?>">
                                <div class="text-xs font-medium uppercase tracking-wide <?php echo e($this->hasResolvedPriceDifference() ? 'text-emerald-700' : 'text-slate-500'); ?>">
                                    Prezzo finale simulato
                                </div>

                                <div class="mt-2 text-lg font-semibold <?php echo e($this->hasResolvedPriceDifference() ? 'text-emerald-700' : 'text-slate-900'); ?>">
                                    <?php echo e($this->formattedResolvedPrice()); ?>

                                </div>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->simulationBreakdown() !== []): ?>
                        <div class="mt-4 rounded-lg border border-slate-200 bg-white">
                            <div class="border-b border-slate-200 px-4 py-3">
                                <h4 class="text-sm font-semibold text-slate-900">
                                    Dettaglio calcolo
                                </h4>
                            </div>

                            <div class="divide-y divide-slate-200">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->simulationBreakdown(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="px-4 py-3 text-sm">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($step['type'] ?? null) === 'base_price'): ?>
                                            <div class="flex items-start justify-between gap-4">
                                                <div>
                                                    <div class="font-medium text-slate-900">
                                                        <?php echo e($step['label'] ?? 'Prezzo base'); ?>

                                                    </div>
                                                </div>

                                                <div class="text-right font-semibold text-slate-900">
                                                    <?php echo e(number_format((float) ($step['amount'] ?? 0), 2, ',', '.')); ?> <?php echo e($this->pricing?->currencyCode() ?? 'EUR'); ?>

                                                </div>
                                            </div>
                                        <?php elseif(($step['type'] ?? null) === 'override'): ?>
                                            <div class="flex items-start justify-between gap-4">
                                                <div>
                                                    <div class="font-medium text-slate-900">
                                                        <?php echo e($step['rule_name'] ?? 'Override'); ?>

                                                    </div>

                                                    <div class="mt-1 text-xs text-slate-500">
                                                        <?php echo e($step['label'] ?? 'Override prezzo'); ?> · Priorità <?php echo e($step['priority'] ?? '-'); ?>

                                                    </div>
                                                </div>

                                                <div class="text-right">
                                                    <div class="font-semibold text-emerald-700">
                                                        <?php echo e(number_format((float) ($step['amount'] ?? 0), 2, ',', '.')); ?> <?php echo e($this->pricing?->currencyCode() ?? 'EUR'); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="flex items-start justify-between gap-4">
                                                <div>
                                                    <div class="font-medium text-slate-900">
                                                        <?php echo e($step['rule_name'] ?? 'Regola'); ?>

                                                    </div>

                                                    <div class="mt-1 text-xs text-slate-500">
                                                        <?php echo e($step['label'] ?? 'Regola'); ?>

                                                        · <?php echo e($this->formatAdjustmentValue($step)); ?>

                                                        · Priorità <?php echo e($step['priority'] ?? '-'); ?>

                                                    </div>
                                                </div>

                                                <div class="text-right">
                                                    <div class="font-semibold <?php echo e(((float) ($step['delta'] ?? 0)) >= 0 ? 'text-emerald-700' : 'text-red-700'); ?>">
                                                        <?php echo e($this->formatDelta($step['delta'] ?? 0)); ?>

                                                    </div>

                                                    <div class="mt-1 text-xs text-slate-500">
                                                        Totale: <?php echo e(number_format((float) ($step['result_price'] ?? 0), 2, ',', '.')); ?> <?php echo e($this->pricing?->currencyCode() ?? 'EUR'); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->ignoredRules() !== []): ?>
                        <div class="mt-4 rounded-lg border border-amber-200 bg-amber-50">
                            <div class="border-b border-amber-200 px-4 py-3">
                                <h4 class="text-sm font-semibold text-amber-900">
                                    Regole compatibili ma ignorate
                                </h4>
                            </div>

                            <div class="divide-y divide-amber-200">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->ignoredRules(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ignoredRule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="px-4 py-3 text-sm">
                                        <div class="flex items-start justify-between gap-4">
                                            <div>
                                                <div class="font-medium text-amber-900">
                                                    <?php echo e($ignoredRule['rule_name'] ?? 'Regola'); ?>

                                                </div>

                                                <div class="mt-1 text-xs text-amber-700">
                                                    Priorità <?php echo e($ignoredRule['priority'] ?? '-'); ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="mt-2 text-sm text-amber-800">
                                            <?php echo e($ignoredRule['reason'] ?? 'Regola compatibile ma non applicata.'); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->matchingRules->isEmpty()): ?>
                        <div class="mt-4 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
                            Nessuna regola risulta compatibile con i dati inseriti.
                        </div>
                    <?php else: ?>
                        <div class="mt-4 space-y-3">
                            <div class="text-sm text-slate-600">
                                Regole potenzialmente compatibili:
                                <span class="font-semibold text-slate-900"><?php echo e($this->matchingRules->count()); ?></span>
                            </div>

                            <div class="space-y-3">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->matchingRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="rounded-lg border border-slate-200 bg-slate-50 p-4">
                                        <div class="flex flex-wrap items-center gap-2">
                                            <div class="font-medium text-slate-900">
                                                <?php echo e($rule->name); ?>

                                            </div>

                                            <span class="inline-flex items-center rounded-full bg-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700">
                                                Priorità <?php echo e($rule->priority); ?>

                                            </span>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($rule->isExclusive()): ?>
                                                <span class="inline-flex items-center rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-700">
                                                    Esclusiva
                                                </span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>

                                        <div class="mt-2 text-sm text-slate-600">
                                            <span class="font-medium text-slate-700">Effetto:</span>
                                            <?php echo e($this->ruleValueLabel($rule)); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->simulationNotes() !== []): ?>
                        <div class="mt-4 space-y-3">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->simulationNotes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
                                    <?php echo e($note); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH C:\laragon\www\b2b.partylegacy.it\resources\views/livewire/vendor/pricings/tabs/pricing-simulation-tab.blade.php ENDPATH**/ ?>