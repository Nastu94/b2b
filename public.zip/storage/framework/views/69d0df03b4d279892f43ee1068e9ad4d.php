
<div class="max-w-4xl mx-auto">
    
    <div class="bg-white shadow-sm rounded-lg p-6">
        <h2 class="text-lg font-semibold">I miei servizi</h2>
        <p class="text-sm text-gray-600 mt-1">
            Seleziona i servizi che offri nella tua categoria.
        </p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
            <div class="mt-4 p-3 rounded bg-green-50 text-green-800 text-sm">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <form wire:submit.prevent="save" class="mt-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $availableOfferings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offering): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-2 p-3 border rounded">
                        <input type="checkbox" wire:model="selectedOfferingIds" value="<?php echo e($offering->id); ?>" />
                        <span><?php echo e($offering->name); ?></span>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="mt-6 flex justify-end">
                <button type="submit"
                    class="inline-flex items-center px-4 py-2 bg-slate-800 text-white rounded hover:bg-slate-700">
                    Salva
                </button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\b2b.partylegacy.it\resources\views/livewire/vendor/offerings/manage-offerings.blade.php ENDPATH**/ ?>