
<div class="max-w-4xl mx-auto">
    <div class="bg-white shadow-sm rounded-lg p-6">
        <h2 class="text-lg font-semibold">Contenuti servizi selezionati</h2>
        <p class="text-sm text-gray-600 mt-1">
            Per ogni servizio attivo, inserisci descrizione e carica immagini (cover + gallery).
        </p>

        <div class="mt-6 space-y-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $activeOfferingIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offeringId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div id="offering-<?php echo e($offeringId); ?>">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.offering-content-card', ['offeringId' => $offeringId]);

$key = 'offering-content-card-' . $offeringId;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-372735732-0', 'offering-content-card-' . $offeringId);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-4 border rounded bg-gray-50 text-sm text-gray-700">
                    Non hai ancora servizi attivi. Vai nella tab “Servizi”, seleziona almeno un servizio e salva.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\b2b.partylegacy.it\resources\views/livewire/vendor/offerings/manage-offering-contents.blade.php ENDPATH**/ ?>