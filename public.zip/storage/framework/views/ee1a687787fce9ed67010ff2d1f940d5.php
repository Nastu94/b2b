<div class="space-y-6">
    
    <div class="space-y-1">
        <h1 class="text-2xl font-semibold tracking-tight text-slate-900">
            Listini
        </h1>

        <p class="text-sm leading-6 text-slate-500">
            Configura il prezzo base del servizio, aggiungi regole commerciali e verifica il comportamento del listino.
        </p>
    </div>

    
    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div class="grid grid-cols-1 gap-5 lg:grid-cols-3">
            <div class="lg:col-span-2">
                <label for="selectedOfferingId" class="mb-2 block text-sm font-medium text-slate-700">
                    Servizio da configurare
                </label>

                <select
                    id="selectedOfferingId"
                    wire:model.live="selectedOfferingId"
                    class="block w-full rounded-xl border-slate-300 text-sm shadow-sm focus:border-slate-400 focus:ring-slate-300"
                >
                    <option value="">-- Seleziona un servizio --</option>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $offerings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offering): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($offering->id); ?>">
                            <?php echo e($offering->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </select>

                <p class="mt-2 text-xs text-slate-500">
                    Scegli il servizio su cui vuoi lavorare prima di modificare listino, regole o simulazione.
                </p>
            </div>

            <div class="rounded-2xl border border-slate-200 bg-slate-50/80 p-4">
                <div class="text-sm font-semibold text-slate-800">
                    Stato configurazione
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->selectedOffering): ?>
                    <div class="mt-3 space-y-2 text-sm text-slate-600">
                        <div>
                            <span class="font-medium text-slate-700">Servizio:</span>
                            <?php echo e($this->selectedOffering->name); ?>

                        </div>

                        <div>
                            <span class="font-medium text-slate-700">Listino base:</span>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->pricingStatus === 'active'): ?>
                                <span class="inline-flex items-center rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-medium text-emerald-700">
                                    Configurato
                                </span>
                            <?php elseif($this->pricingStatus === 'inactive'): ?>
                                <span class="inline-flex items-center rounded-full bg-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700">
                                    Inattivo
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-700">
                                    Da creare
                                </span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="mt-3 text-sm leading-6 text-slate-500">
                        Seleziona un servizio per iniziare a configurare il relativo listino.
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="bg-white shadow rounded-lg">
        <?php
            $tabs = [
                'base-pricing' => 'Listino base',
                'pricing-rules' => 'Regole',
                'pricing-summary' => 'Riepilogo',
                'pricing-simulation' => 'Simulazione',
            ];
        ?>

        <div class="border-b border-slate-200 px-6">
            <nav class="-mb-px flex flex-wrap gap-8" aria-label="Tabs">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabKey => $tabLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button
                        type="button"
                        wire:click="selectTab('<?php echo e($tabKey); ?>')"
                        class="whitespace-nowrap border-b-2 px-1 py-4 text-sm font-medium transition <?php echo e($activeTab === $tabKey ? 'border-slate-800 text-slate-900' : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'); ?>"
                    >
                        <?php echo e($tabLabel); ?>

                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </nav>
        </div>

        
        <div class="p-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedOfferingId === null): ?>
                <div class="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm leading-6 text-amber-800">
                    Per continuare, seleziona prima un servizio dalla lista qui sopra.
                </div>
            <?php else: ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php switch($activeTab):
                    case ('base-pricing'): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.pricings.tabs.pricing-base-tab', ['vendorAccountId' => $vendorAccount->id,'offeringId' => $selectedOfferingId,'pricingId' => $selectedPricingId]);

$key = 'pricing-base-tab-'.$vendorAccount->id.'-'.$selectedOfferingId.'-'.($selectedPricingId ?? 'new');

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-422132244-0', 'pricing-base-tab-'.$vendorAccount->id.'-'.$selectedOfferingId.'-'.($selectedPricingId ?? 'new'));

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php break; ?>

                    <?php case ('pricing-rules'): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.pricings.tabs.pricing-rules-tab', ['pricingId' => $selectedPricingId]);

$key = 'pricing-rules-tab-'.($selectedPricingId ?? 'missing');

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-422132244-1', 'pricing-rules-tab-'.($selectedPricingId ?? 'missing'));

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php break; ?>

                    <?php case ('pricing-summary'): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.pricings.tabs.pricing-summary-tab', ['pricingId' => $selectedPricingId]);

$key = 'pricing-summary-tab-'.($selectedPricingId ?? 'missing');

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-422132244-2', 'pricing-summary-tab-'.($selectedPricingId ?? 'missing'));

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php break; ?>

                    <?php case ('pricing-simulation'): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor.pricings.tabs.pricing-simulation-tab', ['pricingId' => $selectedPricingId]);

$key = 'pricing-simulation-tab-'.($selectedPricingId ?? 'missing');

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-422132244-3', 'pricing-simulation-tab-'.($selectedPricingId ?? 'missing'));

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php break; ?>
                <?php endswitch; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\b2b.partylegacy.it\resources\views/livewire/vendor/pricings/manage-pricings-tabs.blade.php ENDPATH**/ ?>