<div class="p-6">
    <div class="space-y-6">

        <div>
            <h1 class="text-2xl font-semibold text-slate-900">Prenotazioni</h1>
            <p class="mt-1 text-slate-600">Gestione prenotazioni: stato, dettagli e azioni admin.</p>
        </div>

        <div class="bg-white shadow rounded-lg">

            <div class="border-b border-slate-200 px-6">
                <nav class="-mb-px flex gap-8" aria-label="Tabs">

                    <button type="button" wire:click="setTab('pending')"
                        class="whitespace-nowrap border-b-2 px-1 py-4 text-sm font-medium transition
                        <?php echo e($tab === 'pending' ? 'border-slate-800 text-slate-900' : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'); ?>">
                        In attesa
                    </button>

                    <button type="button" wire:click="setTab('confirmed')"
                        class="whitespace-nowrap border-b-2 px-1 py-4 text-sm font-medium transition
                        <?php echo e($tab === 'confirmed' ? 'border-slate-800 text-slate-900' : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'); ?>">
                        Confermate
                    </button>

                    <button type="button" wire:click="setTab('declined')"
                        class="whitespace-nowrap border-b-2 px-1 py-4 text-sm font-medium transition
                        <?php echo e($tab === 'declined' ? 'border-slate-800 text-slate-900' : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'); ?>">
                        Rifiutate
                    </button>

                    <button type="button" wire:click="setTab('all')"
                        class="whitespace-nowrap border-b-2 px-1 py-4 text-sm font-medium transition
                        <?php echo e($tab === 'all' ? 'border-slate-800 text-slate-900' : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'); ?>">
                        Tutte
                    </button>

                </nav>
            </div>

            <div class="p-6">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'pending'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.bookings.admin-bookings-list', ['status' => 'PENDING_VENDOR_CONFIRMATION']);

$key = 'admin-pending';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1890574528-0', 'admin-pending');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php elseif($tab === 'confirmed'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.bookings.admin-bookings-list', ['status' => 'CONFIRMED']);

$key = 'admin-confirmed';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1890574528-1', 'admin-confirmed');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php elseif($tab === 'declined'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.bookings.admin-bookings-list', ['status' => 'DECLINED']);

$key = 'admin-declined';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1890574528-2', 'admin-declined');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php elseif($tab === 'all'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.bookings.admin-bookings-list', ['status' => '']);

$key = 'admin-all';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1890574528-3', 'admin-all');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

        </div>
    </div>
</div><?php /**PATH C:\laragon\www\b2b.partylegacy.it\resources\views/livewire/admin/bookings/admin-bookings-tabs.blade.php ENDPATH**/ ?>