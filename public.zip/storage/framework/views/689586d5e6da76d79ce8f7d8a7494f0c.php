<div class="space-y-6">

    
    <div class="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        <div class="min-w-0">
            <h1 class="text-2xl font-semibold text-slate-900"> <?php echo e(ucfirst($activeTab)); ?></h1>

            <?php
                $displayName = $vendorAccount->company_name
                    ?: trim(($vendorAccount->first_name ?? '') . ' ' . ($vendorAccount->last_name ?? ''))
                    ?: 'Vendor';

                $canUpdate = auth()->user()?->can('update', $vendorAccount) ?? false;
                $canDelete = auth()->user()?->can('delete', $vendorAccount) ?? false;
            ?>

            <p class="mt-1 text-sm text-slate-500">
                <span class="font-medium text-slate-900"><?php echo e($displayName); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($vendorAccount->user?->email): ?>
                    • Email: <span class="font-medium text-slate-900"><?php echo e($vendorAccount->user->email); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </p>
        </div>

        <div class="flex gap-2 shrink-0">
            <a href="<?php echo e(route('admin.dashboard')); ?>"
               class="text-sm px-4 py-2 rounded-lg border border-slate-200 hover:bg-slate-50">
                ← Torna alla lista
            </a>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canUpdate): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!($editing ?? false)): ?>
                    <button type="button" wire:click="enableEditing"
                            class="text-sm px-4 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800">
                        Modifica
                    </button>
                <?php else: ?>
                    <button type="button" wire:click="cancelEditing"
                            class="text-sm px-4 py-2 rounded-lg border border-slate-200 hover:bg-slate-50">
                        Annulla
                    </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canDelete): ?>
                <button type="button" wire:click="confirmDelete"
                        class="text-sm px-4 py-2 rounded-lg border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100">
                    Elimina
                </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <div class="w-full">
        <div class="inline-flex items-center gap-1 rounded-xl bg-slate-100 p-1">
            <button type="button"
                    wire:click="setTab('anagrafica')"
                    class="px-4 py-2 text-sm font-medium rounded-lg transition
                    <?php echo e(($activeTab ?? 'anagrafica') === 'anagrafica'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-white/70'); ?>">
                Anagrafica
            </button>

            <button type="button"
                    wire:click="setTab('servizi')"
                    class="px-4 py-2 text-sm font-medium rounded-lg transition
                    <?php echo e(($activeTab ?? 'anagrafica') === 'servizi'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-white/70'); ?>">
                Servizi
            </button>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($activeTab ?? 'anagrafica') === 'anagrafica'): ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.vendors.tabs.vendor-anagrafica-tab', ['vendorAccountId' => $vendorAccount->id,'editing' => $editing]);

$key = 'admin-vendor-anagrafica-'.e($vendorAccount->id).'';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1900156299-0', 'admin-vendor-anagrafica-'.e($vendorAccount->id).'');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($activeTab ?? 'anagrafica') === 'servizi'): ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.vendors.tabs.vendor-servizi-tab', ['vendorAccountId' => $vendorAccount->id]);

$key = 'admin-vendor-servizi-'.e($vendorAccount->id).'';

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1900156299-1', 'admin-vendor-servizi-'.e($vendorAccount->id).'');

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($confirmingDelete && ($canDelete ?? false)): ?>
        <div class="fixed inset-0 bg-black/30 flex items-center justify-center p-4">
            <div class="w-full max-w-md bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h3 class="text-lg font-semibold text-slate-900">Conferma eliminazione</h3>
                <p class="mt-2 text-sm text-slate-600">
                    Vuoi eliminare questo vendor?
                </p>

                <div class="mt-6 flex justify-end gap-2">
                    <button type="button" wire:click="cancelDelete"
                            class="text-sm px-4 py-2 rounded-lg border border-slate-200 hover:bg-slate-50">
                        Annulla
                    </button>

                    <button type="button" wire:click="deleteVendor"
                            class="text-sm px-4 py-2 rounded-lg bg-rose-600 text-white hover:bg-rose-700"
                            <?php if(!($canDelete ?? false)): echo 'disabled'; endif; ?>>
                        Elimina
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div><?php /**PATH C:\laragon\www\b2b.partylegacy.it\resources\views/livewire/admin/vendors/vendor-profile-tabs.blade.php ENDPATH**/ ?>